import { Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState, type ReactNode } from "react";
import { ClipboardCheck, LayoutDashboard, Package, Plus, Truck } from "lucide-react";
import { RedirectToSignIn, UserButton } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { createHospital, getWorkspace } from "@/lib/crash/api";
import { roleLabel } from "@/lib/crash/catalog";

const KEY = "cartcheck-hospital";

export type HospitalPick = { id: string; name: string; code: string; role: string };

export function HospitalGate({
  title,
  subtitle,
  children,
}: {
  title: string;
  subtitle?: string;
  children: (hospital: HospitalPick) => ReactNode;
}) {
  const { user, isPending } = useCurrentUserState();
  const [hospital, setHospital] = useState<HospitalPick | null>(null);
  const [hospitals, setHospitals] = useState<HospitalPick[]>([]);
  const [empty, setEmpty] = useState(false);
  const [isSuper, setIsSuper] = useState(false);
  const [error, setError] = useState("");
  const navigate = useNavigate();

  async function load() {
    const ws = await getWorkspace();
    setHospitals(ws.hospitals);
    setIsSuper(ws.isSuper);
    if (!ws.hospitals.length) {
      setEmpty(true);
      setHospital(null);
      return;
    }
    setEmpty(false);
    const saved = localStorage.getItem(KEY);
    const pick = ws.hospitals.find((h) => h.id === saved) ?? ws.hospitals[0];
    setHospital(pick);
    localStorage.setItem(KEY, pick.id);
  }

  useEffect(() => {
    if (!user) return;
    load().catch((e: Error) => setError(e.message));
  }, [user?.id]);

  if (isPending || (user && !hospital && !empty && !error)) {
    return <main className="grid min-h-screen place-items-center text-muted">Loading CartCheck…</main>;
  }
  if (!user) return <RedirectToSignIn />;
  if (error) return <main className="mx-auto max-w-lg p-8 text-warn">{error}</main>;
  if (empty || !hospital) {
    return (
      <main className="mx-auto max-w-lg px-4 py-12">
        <p className="font-display text-3xl text-ink">
          {isSuper ? "Add the first hospital" : "Waiting for a hospital"}
        </p>
        <p className="mt-2 text-muted">
          {isSuper
            ? "Only Super Admin can open a hospital. Each one keeps its own crash carts and item list."
            : "Ask Super Admin to add your hospital and invite your work email."}
        </p>
        {isSuper ? (
          <CreateHospital
            onCreated={async (id) => {
              localStorage.setItem(KEY, id);
              await load();
              navigate({ to: "/" });
            }}
          />
        ) : null}
      </main>
    );
  }

  const links = [
    { to: "/", label: "Floor", icon: LayoutDashboard },
    { to: "/carts", label: "Carts", icon: Truck },
    { to: "/items", label: "Items", icon: Package },
    { to: "/audits", label: "Audits", icon: ClipboardCheck },
  ] as const;

  return (
    <div className="min-h-screen">
      <header className="border-b border-line bg-surface">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center gap-3 px-4 py-3">
          <Link to="/" className="font-display text-2xl tracking-tight text-primary">
            CartCheck
          </Link>
          <select
            className="min-h-11 w-full max-w-xs rounded-lg border border-line bg-bg px-3 py-2 text-sm sm:ml-2 sm:w-auto"
            value={hospital.id}
            onChange={(e) => {
              localStorage.setItem(KEY, e.target.value);
              const next = hospitals.find((h) => h.id === e.target.value);
              if (next) setHospital(next);
            }}
          >
            {hospitals.map((h) => (
              <option key={h.id} value={h.id}>
                {h.name} · {roleLabel(h.role)}
              </option>
            ))}
          </select>
          <div className="ml-auto">
            <UserButton />
          </div>
        </div>
        <nav className="mx-auto flex max-w-6xl gap-1 overflow-x-auto px-3 pb-3">
          {links.map((l) => (
            <Link
              key={l.to}
              to={l.to}
              activeOptions={{ exact: l.to === "/" }}
              activeProps={{
                className:
                  "inline-flex min-h-11 items-center gap-2 rounded-full bg-primary px-4 text-sm text-primary-ink",
              }}
              inactiveProps={{
                className:
                  "inline-flex min-h-11 items-center gap-2 rounded-full px-4 text-sm text-ink hover:bg-bg",
              }}
            >
              <l.icon size={16} />
              {l.label}
            </Link>
          ))}
        </nav>
      </header>
      <main className="mx-auto max-w-6xl px-4 py-6">
        <h1 className="font-display text-3xl text-ink">{title}</h1>
        {subtitle ? <p className="mt-1 max-w-2xl text-muted">{subtitle}</p> : null}
        <div className="mt-6">{children(hospital)}</div>
      </main>
    </div>
  );
}

function CreateHospital({ onCreated }: { onCreated: (id: string) => Promise<void> }) {
  const [name, setName] = useState("");
  const [code, setCode] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  return (
    <form
      className="mt-6 space-y-3 rounded-card border border-line bg-surface p-4"
      onSubmit={async (e) => {
        e.preventDefault();
        setBusy(true);
        setError("");
        try {
          const res = await createHospital({ data: { name, code } });
          await onCreated(res.id);
        } catch (err) {
          setError(err instanceof Error ? err.message : "Could not create hospital");
        } finally {
          setBusy(false);
        }
      }}
    >
      <label className="block text-sm">
        Hospital name
        <input
          className="mt-1 min-h-11 w-full rounded-lg border border-line bg-bg px-3"
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="City General"
          required
        />
      </label>
      <label className="block text-sm">
        Short code
        <input
          className="mt-1 min-h-11 w-full rounded-lg border border-line bg-bg px-3 uppercase"
          value={code}
          onChange={(e) => setCode(e.target.value)}
          placeholder="CGH"
          required
        />
      </label>
      {error ? <p className="text-sm text-warn">{error}</p> : null}
      <button
        type="submit"
        disabled={busy}
        className="inline-flex min-h-11 items-center gap-2 rounded-full bg-primary px-5 text-primary-ink disabled:opacity-60"
      >
        <Plus size={16} />
        {busy ? "Creating…" : "Create hospital"}
      </button>
      <p className="text-sm text-muted">
        A standard medicine and surgical list is loaded with three starter carts: ICU, Emergency, and
        Ward. Every line can be changed later.
      </p>
    </form>
  );
}
