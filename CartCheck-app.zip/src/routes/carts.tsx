import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { HospitalGate, type HospitalPick } from "@/components/shell";
import { createCart, listCarts } from "@/lib/crash/api";

export const Route = createFileRoute("/carts")({ component: Page });

function Page() {
  return (
    <HospitalGate
      title="Crash carts"
      subtitle="Each floor can keep a different fixed list. ICU, emergency, and wards do not have to match."
    >
      {(h) => <Carts hospital={h} />}
    </HospitalGate>
  );
}

function Carts({ hospital }: { hospital: HospitalPick }) {
  const [data, setData] = useState<Awaited<ReturnType<typeof listCarts>> | null>(null);
  const [name, setName] = useState("");
  const [location, setLocation] = useState("");
  const [cartType, setCartType] = useState("Ward");
  const [error, setError] = useState("");

  async function load() {
    setData(await listCarts({ data: { hospitalId: hospital.id } }));
  }
  useEffect(() => {
    load().catch((e: Error) => setError(e.message));
  }, [hospital.id]);

  if (error) return <p className="text-warn">{error}</p>;
  if (!data) return <p className="text-muted">Loading carts…</p>;

  return (
    <div className="grid gap-6 lg:grid-cols-[1fr_280px]">
      <ul className="space-y-3">
        {data.carts.map((c) => (
          <li key={c.id} className="rounded-card border border-line bg-surface p-4">
            <div className="flex items-start justify-between gap-3">
              <div>
                <p className="font-medium">{c.name}</p>
                <p className="text-sm text-muted">
                  {c.cart_type} · {c.location}
                </p>
                <p className="mt-2 text-sm">
                  {c.drawers} floors · {c.lines} items
                </p>
              </div>
              <Link
                to="/carts/$cartId"
                params={{ cartId: c.id }}
                className="inline-flex min-h-11 items-center rounded-full bg-primary px-4 text-sm text-primary-ink"
              >
                Open
              </Link>
            </div>
          </li>
        ))}
      </ul>
      {data.role === "hospital_admin" || data.role === "super_admin" ? (
        <form
          className="h-fit space-y-3 rounded-card border border-line bg-surface p-4"
          onSubmit={async (e) => {
            e.preventDefault();
            try {
              await createCart({ data: { hospitalId: hospital.id, name, location, cartType } });
              setName("");
              setLocation("");
              await load();
            } catch (err) {
              setError(err instanceof Error ? err.message : "Could not create cart");
            }
          }}
        >
          <h2 className="font-medium">New trolley</h2>
          <input
            required
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="OT Crash Cart"
            className="min-h-11 w-full rounded-lg border border-line bg-bg px-3"
          />
          <input
            required
            value={location}
            onChange={(e) => setLocation(e.target.value)}
            placeholder="Operation theatre"
            className="min-h-11 w-full rounded-lg border border-line bg-bg px-3"
          />
          <select
            value={cartType}
            onChange={(e) => setCartType(e.target.value)}
            className="min-h-11 w-full rounded-lg border border-line bg-bg px-3"
          >
            {["ICU", "Emergency", "Ward", "OT", "Other"].map((t) => (
              <option key={t}>{t}</option>
            ))}
          </select>
          <button type="submit" className="min-h-11 w-full rounded-full bg-primary text-primary-ink">
            Add cart
          </button>
          <p className="text-sm text-muted">New carts start with four empty floors. Add medicine, surgical, or misc on any floor.</p>
        </form>
      ) : null}
    </div>
  );
}
