import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { authClient, authEnabled } from "@/lib/auth/client";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { ensureSuperAdmin } from "@/lib/crash/api";

export const Route = createFileRoute("/login")({ component: Login });

function Login() {
  const { user, isPending } = useCurrentUserState();
  const navigate = useNavigate();
  const [loginId, setLoginId] = useState("SuperAdmin");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    ensureSuperAdmin().catch(() => {});
  }, []);

  useEffect(() => {
    if (!isPending && user) navigate({ to: "/" });
  }, [isPending, user, navigate]);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError("");
    try {
      await ensureSuperAdmin();
      const email =
        loginId.trim().toLowerCase() === "superadmin" ? "superadmin@cartcheck.local" : loginId.trim();
      const res = await authClient.signIn.email({ email, password, callbackURL: "/" });
      if (res.error) throw new Error(res.error.message || "Could not sign in");
      navigate({ to: "/" });
    } catch (err) {
      setError(err instanceof Error ? err.message : "Sign-in failed");
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="mx-auto grid min-h-screen max-w-5xl items-center gap-10 px-4 py-12 md:grid-cols-2">
      <div>
        <p className="text-sm font-medium tracking-wide text-primary">Hospital pharmacy</p>
        <h1 className="mt-2 font-display text-5xl leading-tight text-ink">Crash carts, checked on time.</h1>
        <p className="mt-4 max-w-md text-muted">
          Super Admin opens hospitals. Each hospital’s trolleys have numbered floors. Every floor can hold
          medicines, surgicals, and miscellaneous items.
        </p>
      </div>
      <form className="space-y-3 rounded-card border border-line bg-surface p-5" onSubmit={onSubmit}>
        <h2 className="font-display text-2xl">Sign in</h2>
        {authEnabled ? (
          <>
            <label className="block text-sm">
              ID
              <input
                className="mt-1 min-h-11 w-full rounded-lg border border-line bg-bg px-3"
                value={loginId}
                onChange={(e) => setLoginId(e.target.value)}
                autoComplete="username"
                required
              />
            </label>
            <label className="block text-sm">
              Password
              <input
                type="password"
                className="mt-1 min-h-11 w-full rounded-lg border border-line bg-bg px-3"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                autoComplete="current-password"
                required
              />
            </label>
            {error ? <p className="text-sm text-warn">{error}</p> : null}
            <button
              type="submit"
              disabled={busy}
              className="min-h-11 w-full rounded-full bg-primary text-primary-ink disabled:opacity-60"
            >
              {busy ? "Please wait…" : "Sign in"}
            </button>
            <p className="text-sm text-muted">Super Admin ID is SuperAdmin. Staff sign in with the email they were invited with.</p>
          </>
        ) : (
          <p className="text-sm text-muted">Sign-in is disabled.</p>
        )}
      </form>
    </main>
  );
}
