import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { HospitalGate, type HospitalPick } from "@/components/shell";
import { addFloorItem, getCart } from "@/lib/crash/api";

export const Route = createFileRoute("/carts/$cartId")({ component: Page });

function Page() {
  const { cartId } = Route.useParams();
  return (
    <HospitalGate title="Cart layout" subtitle="Each floor can hold medicines, surgicals, and miscellaneous items.">
      {(h) => <Layout hospital={h} cartId={cartId} />}
    </HospitalGate>
  );
}

function Layout({ hospital, cartId }: { hospital: HospitalPick; cartId: string }) {
  const [data, setData] = useState<Awaited<ReturnType<typeof getCart>> | null>(null);
  const [error, setError] = useState("");

  async function load() {
    const next = await getCart({ data: { hospitalId: hospital.id, cartId } });
    setData(next);
  }

  useEffect(() => {
    load().catch((e: Error) => setError(e.message));
  }, [hospital.id, cartId]);

  if (error) return <p className="text-warn">{error}</p>;
  if (!data) return <p className="text-muted">Loading layout…</p>;

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="font-display text-2xl">{data.cart.name}</p>
          <p className="text-sm text-muted">
            {data.cart.cart_type} · {data.cart.location}
          </p>
        </div>
        <Link to="/audits" className="inline-flex min-h-11 items-center rounded-full border border-line bg-surface px-4 text-sm">
          Audit this cart
        </Link>
      </div>
      <div className="grid gap-4 md:grid-cols-2">
        {data.drawers.map((d) => (
          <FloorCard
            key={d.id}
            name={d.name}
            lines={data.lines.filter((l) => l.drawer_id === d.id)}
            canEdit={data.role === "hospital_admin" || data.role === "super_admin"}
            onAdd={async (input) => {
              await addFloorItem({
                data: { hospitalId: hospital.id, drawerId: d.id, ...input },
              });
              await load();
            }}
          />
        ))}
      </div>
    </div>
  );
}

function FloorCard({
  name,
  lines,
  canEdit,
  onAdd,
}: {
  name: string;
  lines: { id: string; name: string; kind: string; strength: string; fixed_qty: number }[];
  canEdit: boolean;
  onAdd: (input: { name: string; kind: string; strength: string; qty: number }) => Promise<void>;
}) {
  const [kind, setKind] = useState("medicine");
  const [itemName, setItemName] = useState("");
  const [strength, setStrength] = useState("");
  const [qty, setQty] = useState(1);
  const [error, setError] = useState("");
  return (
    <section className="rounded-card border border-line bg-surface">
      <h2 className="border-b border-line px-4 py-3 font-medium">{name}</h2>
      <ul>
        {lines.map((l) => (
          <li key={l.id} className="border-b border-line px-4 py-2 text-sm last:border-0">
            <span className="font-medium">{l.name}</span>
            <span className="text-muted">
              {" "}
              · {l.kind}
              {l.strength ? ` · ${l.strength}` : ""} · qty {l.fixed_qty}
            </span>
          </li>
        ))}
        {lines.length === 0 ? <li className="px-4 py-4 text-sm text-muted">Nothing on this floor yet.</li> : null}
      </ul>
      {canEdit ? (
        <form
          className="space-y-2 border-t border-line p-3"
          onSubmit={async (e) => {
            e.preventDefault();
            setError("");
            try {
              await onAdd({ name: itemName, kind, strength, qty });
              setItemName("");
              setStrength("");
              setQty(1);
            } catch (err) {
              setError(err instanceof Error ? err.message : "Could not add");
            }
          }}
        >
          <div className="flex gap-1">
            {[
              ["medicine", "Medicine"],
              ["surgical", "Surgical"],
              ["misc", "Misc"],
            ].map(([id, label]) => (
              <button
                key={id}
                type="button"
                onClick={() => setKind(id)}
                className={`min-h-10 flex-1 rounded-full text-sm ${kind === id ? "bg-primary text-primary-ink" : "bg-bg"}`}
              >
                {label}
              </button>
            ))}
          </div>
          <input
            required
            value={itemName}
            onChange={(e) => setItemName(e.target.value)}
            placeholder="Item name"
            className="min-h-11 w-full rounded-lg border border-line bg-bg px-3"
          />
          <div className="flex gap-2">
            <input
              value={strength}
              onChange={(e) => setStrength(e.target.value)}
              placeholder="Strength"
              className="min-h-11 min-w-0 flex-1 rounded-lg border border-line bg-bg px-3"
            />
            <input
              type="number"
              min={1}
              value={qty}
              onChange={(e) => setQty(Number(e.target.value))}
              className="min-h-11 w-20 rounded-lg border border-line bg-bg px-3"
            />
          </div>
          {error ? <p className="text-sm text-warn">{error}</p> : null}
          <button type="submit" className="min-h-11 w-full rounded-full bg-primary text-sm text-primary-ink">
            Add to this floor
          </button>
        </form>
      ) : null}
    </section>
  );
}
