import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { HospitalGate, type HospitalPick } from "@/components/shell";
import { getAudit, saveLine, setAuditStatus } from "@/lib/crash/api";

export const Route = createFileRoute("/audits/$auditId")({ component: Page });

const STATUSES = [
  { id: "present", label: "Present" },
  { id: "absent", label: "Absent" },
  { id: "expired", label: "Expired" },
  { id: "near_expiry", label: "Near expiry" },
  { id: "damaged", label: "Damaged" },
] as const;

const LABELS = [
  { id: "", label: "Label ok" },
  { id: "missing", label: "Missing label" },
  { id: "wrong", label: "Wrong label" },
  { id: "incomplete", label: "Incomplete label" },
] as const;

function Page() {
  const { auditId } = Route.useParams();
  return (
    <HospitalGate title="Checklist" subtitle="Work drawer by drawer. Changes save as you go while the audit is a draft.">
      {(h) => <Sheet hospital={h} auditId={auditId} />}
    </HospitalGate>
  );
}

type Line = Awaited<ReturnType<typeof getAudit>>["lines"][number];

function Sheet({ hospital, auditId }: { hospital: HospitalPick; auditId: string }) {
  const [pack, setPack] = useState<Awaited<ReturnType<typeof getAudit>> | null>(null);
  const [error, setError] = useState("");
  const [remarks, setRemarks] = useState("");

  async function load() {
    const next = await getAudit({ data: { hospitalId: hospital.id, auditId } });
    setPack(next);
    setRemarks(next.audit.remarks);
  }

  useEffect(() => {
    load().catch((e: Error) => setError(e.message));
  }, [hospital.id, auditId]);

  if (error) return <p className="text-warn">{error}</p>;
  if (!pack) return <p className="text-muted">Loading checklist…</p>;

  const drawers = [...new Set(pack.lines.map((l) => l.drawer_name))];
  const gaps = pack.lines.filter((l) => l.line_status !== "present" || l.label_note).length;
  const draft = pack.audit.status === "draft";
  const canEdit = draft && ["hospital_admin", "pharmacy", "quality", "super_admin"].includes(pack.role);
  const canClose = ["hospital_admin", "quality", "manager", "super_admin"].includes(pack.role);

  async function patch(line: Line, partial: Partial<Line>) {
    const next = { ...line, ...partial };
    setPack((p) =>
      p ? { ...p, lines: p.lines.map((l) => (l.id === line.id ? next : l)) } : p,
    );
    await saveLine({
      data: {
        hospitalId: hospital.id,
        lineId: line.id,
        lineStatus: next.line_status,
        labelNote: next.label_note,
        remarks: next.remarks,
      },
    });
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="font-display text-2xl">{pack.audit.cart_name}</p>
          <p className="text-sm capitalize text-muted">
            {pack.audit.location} · {pack.audit.audit_type} · {pack.audit.status} · {gaps} observations
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          {canEdit ? (
            <button
              type="button"
              className="min-h-11 rounded-full bg-primary px-4 text-primary-ink"
              onClick={() =>
                setAuditStatus({
                  data: { hospitalId: hospital.id, auditId, status: "submitted", remarks },
                }).then(load)
              }
            >
              Submit
            </button>
          ) : null}
          {canClose && pack.audit.status === "submitted" ? (
            <button
              type="button"
              className="min-h-11 rounded-full border border-line bg-surface px-4"
              onClick={() =>
                setAuditStatus({
                  data: { hospitalId: hospital.id, auditId, status: "closed", remarks },
                }).then(load)
              }
            >
              Close
            </button>
          ) : null}
        </div>
      </div>
      <label className="block text-sm">
        Overall remarks
        <textarea
          value={remarks}
          onChange={(e) => setRemarks(e.target.value)}
          onBlur={() =>
            setAuditStatus({
              data: { hospitalId: hospital.id, auditId, status: pack.audit.status, remarks },
            })
          }
          className="mt-1 min-h-20 w-full rounded-lg border border-line bg-surface px-3 py-2"
        />
      </label>
      {drawers.map((name) => (
        <section key={name} className="overflow-hidden rounded-card border border-line bg-surface">
          <h2 className="border-b border-line px-4 py-3 font-medium">{name}</h2>
          <ul>
            {pack.lines
              .filter((l) => l.drawer_name === name)
              .map((line) => (
                <li key={line.id} className="grid gap-2 border-b border-line px-4 py-3 last:border-0 md:grid-cols-[1.2fr_1fr_1fr]">
                  <div>
                    <p className="font-medium">{line.item_name}</p>
                    <p className="text-sm text-muted">Fixed qty {line.fixed_qty}</p>
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {STATUSES.map((s) => (
                      <button
                        key={s.id}
                        type="button"
                        disabled={!canEdit}
                        onClick={() => patch(line, { line_status: s.id })}
                        className={`min-h-10 rounded-full px-3 text-sm ${
                          line.line_status === s.id
                            ? s.id === "present"
                              ? "bg-ok text-primary-ink"
                              : "bg-warn text-primary-ink"
                            : "bg-bg"
                        }`}
                      >
                        {s.label}
                      </button>
                    ))}
                  </div>
                  <select
                    disabled={!canEdit}
                    value={line.label_note}
                    onChange={(e) => patch(line, { label_note: e.target.value })}
                    className="min-h-11 rounded-lg border border-line bg-bg px-3 text-sm"
                  >
                    {LABELS.map((l) => (
                      <option key={l.id} value={l.id}>
                        {l.label}
                      </option>
                    ))}
                  </select>
                </li>
              ))}
          </ul>
        </section>
      ))}
    </div>
  );
}
