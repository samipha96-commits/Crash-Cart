import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { HospitalGate, type HospitalPick } from "@/components/shell";
import { getDashboard, inviteMember, listMembers, createHospital } from "@/lib/crash/api";
import { roleLabel } from "@/lib/crash/catalog";

export const Route = createFileRoute("/")({ component: Page });

function Page() {
  return (
    <HospitalGate
      title="Floor board"
      subtitle="Open audits, carts on the floor, and who can sign the checklist."
    >
      {(hospital) => <Board hospital={hospital} />}
    </HospitalGate>
  );
}

function Board({ hospital }: { hospital: HospitalPick }) {
  const [data, setData] = useState<Awaited<ReturnType<typeof getDashboard>> | null>(null);
  const [members, setMembers] = useState<Awaited<ReturnType<typeof listMembers>> | null>(null);
  const [error, setError] = useState("");
  const [email, setEmail] = useState("");
  const [role, setRole] = useState("pharmacy");
  const [hospName, setHospName] = useState("");
  const [hospCode, setHospCode] = useState("");
  const [note, setNote] = useState("");

  useEffect(() => {
    setData(null);
    Promise.all([getDashboard({ data: { hospitalId: hospital.id } }), listMembers({ data: { hospitalId: hospital.id } })])
      .then(([d, m]) => {
        setData(d);
        setMembers(m);
      })
      .catch((e: Error) => setError(e.message));
  }, [hospital.id]);

  if (error) return <p className="text-warn">{error}</p>;
  if (!data || !members) return <p className="text-muted">Loading floor…</p>;

  const cards = [
    { label: "Crash carts", value: data.cartCount },
    { label: "Open audits", value: data.openAudits },
    { label: "Open gaps", value: data.openGaps },
  ];

  return (
    <div className="grid gap-6 lg:grid-cols-[1.4fr_0.8fr]">
      <section className="space-y-4">
        <div className="grid grid-cols-3 gap-3">
          {cards.map((c) => (
            <div key={c.label} className="rounded-card border border-line bg-surface p-4">
              <p className="text-sm text-muted">{c.label}</p>
              <p className="font-display text-3xl">{c.value}</p>
            </div>
          ))}
        </div>
        <div className="rounded-card border border-line bg-surface">
          <div className="flex items-center justify-between border-b border-line px-4 py-3">
            <h2 className="font-medium">Carts</h2>
            <Link to="/audits" className="text-sm text-primary">
              Start an audit
            </Link>
          </div>
          <ul>
            {data.carts.map((c) => (
              <li key={c.id} className="flex items-center justify-between gap-3 border-b border-line px-4 py-3 last:border-0">
                <div>
                  <p className="font-medium">{c.name}</p>
                  <p className="text-sm text-muted">
                    {c.cart_type} · {c.location}
                  </p>
                </div>
                <Link to="/carts/$cartId" params={{ cartId: c.id }} className="text-sm text-primary">
                  Layout
                </Link>
              </li>
            ))}
          </ul>
        </div>
        <div className="rounded-card border border-line bg-surface">
          <h2 className="border-b border-line px-4 py-3 font-medium">Recent audits</h2>
          {data.recent.length === 0 ? (
            <p className="px-4 py-6 text-sm text-muted">No audits yet. Pharmacy or quality can start a monthly or quarterly check.</p>
          ) : (
            <ul>
              {data.recent.map((a) => (
                <li key={a.id} className="flex items-center justify-between gap-3 border-b border-line px-4 py-3 last:border-0">
                  <div>
                    <p className="font-medium">{a.cart_name}</p>
                    <p className="text-sm capitalize text-muted">
                      {a.audit_type} · {a.status}
                    </p>
                  </div>
                  <Link to="/audits/$auditId" params={{ auditId: a.id }} className="text-sm text-primary">
                    Open
                  </Link>
                </li>
              ))}
            </ul>
          )}
        </div>
      </section>
      <aside className="space-y-4">
      {data.isSuper ? (
        <form
          className="rounded-card border border-line bg-surface p-4 space-y-2"
          onSubmit={async (e) => {
            e.preventDefault();
            setNote("");
            try {
              await createHospital({ data: { name: hospName, code: hospCode } });
              setHospName("");
              setHospCode("");
              setNote("Hospital added. Switch to it from the menu.");
              window.location.reload();
            } catch (err) {
              setNote(err instanceof Error ? err.message : "Could not add hospital");
            }
          }}
        >
          <h2 className="font-medium">Add hospital</h2>
          <input required value={hospName} onChange={(e) => setHospName(e.target.value)} placeholder="Hospital name" className="min-h-11 w-full rounded-lg border border-line bg-bg px-3" />
          <input required value={hospCode} onChange={(e) => setHospCode(e.target.value)} placeholder="Code" className="min-h-11 w-full rounded-lg border border-line bg-bg px-3 uppercase" />
          <button type="submit" className="min-h-11 w-full rounded-full bg-primary text-primary-ink">Add hospital</button>
        </form>
      ) : null}
      <div className="rounded-card border border-line bg-surface p-4">
        <h2 className="font-medium">People</h2>
        <p className="mt-1 text-sm text-muted">Your role here is {roleLabel(data.role)}.</p>
        <ul className="mt-3 space-y-2 text-sm">
          {members.members.map((m) => (
            <li key={m.email} className="flex justify-between gap-2">
              <span>{m.name || m.email}</span>
              <span className="text-muted">{roleLabel(m.role)}</span>
            </li>
          ))}
          {members.pending.map((m) => (
            <li key={m.email} className="flex justify-between gap-2 text-muted">
              <span>{m.email}</span>
              <span>Invited · {roleLabel(m.role)}</span>
            </li>
          ))}
        </ul>
        {data.role === "hospital_admin" || data.role === "super_admin" ? (
          <form
            className="mt-4 space-y-2 border-t border-line pt-4"
            onSubmit={async (e) => {
              e.preventDefault();
              setNote("");
              try {
                const res = await inviteMember({ data: { hospitalId: hospital.id, email, role } });
                setNote(res.joined ? "Added to this hospital." : "Invite saved. They join when they sign up with that email.");
                setEmail("");
                setMembers(await listMembers({ data: { hospitalId: hospital.id } }));
              } catch (err) {
                setNote(err instanceof Error ? err.message : "Could not invite");
              }
            }}
          >
            <p className="text-sm font-medium">Invite by email</p>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="pharmacy@hospital.org"
              className="min-h-11 w-full rounded-lg border border-line bg-bg px-3"
            />
            <select
              value={role}
              onChange={(e) => setRole(e.target.value)}
              className="min-h-11 w-full rounded-lg border border-line bg-bg px-3"
            >
              <option value="pharmacy">Pharmacy</option>
              <option value="quality">Quality</option>
              <option value="manager">Manager</option>
              <option value="hospital_admin">Hospital admin</option>
            </select>
            <button type="submit" className="min-h-11 w-full rounded-full bg-primary text-primary-ink">
              Invite
            </button>
            {note ? <p className="text-sm text-muted">{note}</p> : null}
          </form>
        ) : null}
      </div>
      </aside>
    </div>
  );
}
