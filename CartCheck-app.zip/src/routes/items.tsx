import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { HospitalGate, type HospitalPick } from "@/components/shell";
import { addItem, listItems } from "@/lib/crash/api";

export const Route = createFileRoute("/items")({ component: Page });

function Page() {
  return (
    <HospitalGate
      title="Item master"
      subtitle="Medicines and surgicals for this hospital. Assign them onto each cart’s drawers."
    >
      {(hospital) => <Items hospital={hospital} />}
    </HospitalGate>
  );
}

function Items({ hospital }: { hospital: HospitalPick }) {
  const [rows, setRows] = useState<Awaited<ReturnType<typeof listItems>> | null>(null);
  const [kind, setKind] = useState<"all" | "medicine" | "surgical" | "misc">("all");
  const [name, setName] = useState("");
  const [newKind, setNewKind] = useState("medicine");
  const [category, setCategory] = useState("");
  const [strength, setStrength] = useState("");
  const [error, setError] = useState("");

  async function load() {
    setRows(await listItems({ data: { hospitalId: hospital.id } }));
  }

  useEffect(() => {
    load().catch((e: Error) => setError(e.message));
  }, [hospital.id]);

  if (error) return <p className="text-warn">{error}</p>;
  if (!rows) return <p className="text-muted">Loading items…</p>;

  const shown = rows.items.filter((i) => kind === "all" || i.kind === kind);
  const admin = rows.role === "hospital_admin" || rows.role === "super_admin";

  return (
    <div className="grid gap-6 lg:grid-cols-[1fr_280px]">
      <div>
        <div className="mb-3 flex gap-2">
          {(["all", "medicine", "surgical", "misc"] as const).map((k) => (
            <button
              key={k}
              type="button"
              onClick={() => setKind(k)}
              className={`min-h-11 rounded-full px-4 capitalize ${kind === k ? "bg-primary text-primary-ink" : "bg-surface border border-line"}`}
            >
              {k}
            </button>
          ))}
        </div>
        <ul className="divide-y divide-line overflow-hidden rounded-card border border-line bg-surface">
          {shown.map((item) => (
            <li key={item.id} className="flex items-center justify-between gap-3 px-4 py-3">
              <div>
                <p className="font-medium">{item.name}</p>
                <p className="text-sm text-muted">
                  {item.kind} · {item.category}
                  {item.strength ? ` · ${item.strength}` : ""}
                </p>
              </div>
            </li>
          ))}
        </ul>
      </div>
      {admin ? (
        <form
          className="h-fit space-y-3 rounded-card border border-line bg-surface p-4"
          onSubmit={async (e) => {
            e.preventDefault();
            setError("");
            try {
              await addItem({
                data: { hospitalId: hospital.id, name, kind: newKind, category, strength },
              });
              setName("");
              setCategory("");
              setStrength("");
              await load();
            } catch (err) {
              setError(err instanceof Error ? err.message : "Could not add");
            }
          }}
        >
          <h2 className="font-medium">Add to the list</h2>
          <input
            required
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Item name"
            className="min-h-11 w-full rounded-lg border border-line bg-bg px-3"
          />
          <select
            value={newKind}
            onChange={(e) => setNewKind(e.target.value)}
            className="min-h-11 w-full rounded-lg border border-line bg-bg px-3"
          >
            <option value="medicine">Medicine</option>
            <option value="surgical">Surgical</option>
            <option value="misc">Misc</option>
          </select>
          <input
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            placeholder="Category (ACLS, Airway…)"
            className="min-h-11 w-full rounded-lg border border-line bg-bg px-3"
          />
          <input
            value={strength}
            onChange={(e) => setStrength(e.target.value)}
            placeholder="Strength (optional)"
            className="min-h-11 w-full rounded-lg border border-line bg-bg px-3"
          />
          <button type="submit" className="min-h-11 w-full rounded-full bg-primary text-primary-ink">
            Add item
          </button>
        </form>
      ) : (
        <p className="text-sm text-muted">Only a hospital admin can add medicines or surgicals.</p>
      )}
    </div>
  );
}
