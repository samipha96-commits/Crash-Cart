import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { HospitalGate, type HospitalPick } from "@/components/shell";
import { listAudits, startAudit } from "@/lib/crash/api";

export const Route = createFileRoute("/audits")({ component: Page });

function Page() {
  return (
    <HospitalGate
      title="Audits"
      subtitle="Monthly and quarterly checks. Tick presence, expiry, damage, and labeling."
    >
      {(h) => <Audits hospital={h} />}
    </HospitalGate>
  );
}

function Audits({ hospital }: { hospital: HospitalPick }) {
  const navigate = useNavigate();
  const [data, setData] = useState<Awaited<ReturnType<typeof listAudits>> | null>(null);
  const [cartId, setCartId] = useState("");
  const [auditType, setAuditType] = useState("monthly");
  const [error, setError] = useState("");

  useEffect(() => {
    listAudits({ data: { hospitalId: hospital.id } })
      .then((d) => {
        setData(d);
        setCartId((c) => c || d.carts[0]?.id || "");
      })
      .catch((e: Error) => setError(e.message));
  }, [hospital.id]);

  if (error) return <p className="text-warn">{error}</p>;
  if (!data) return <p className="text-muted">Loading audits…</p>;

  const canAudit = ["hospital_admin", "pharmacy", "quality", "super_admin"].includes(data.role);

  return (
    <div className="space-y-6">
      {canAudit ? (
        <form
          className="flex flex-wrap items-end gap-2 rounded-card border border-line bg-surface p-4"
          onSubmit={async (e) => {
            e.preventDefault();
            try {
              const res = await startAudit({
                data: { hospitalId: hospital.id, cartId, auditType },
              });
              navigate({ to: "/audits/$auditId", params: { auditId: res.id } });
            } catch (err) {
              setError(err instanceof Error ? err.message : "Could not start");
            }
          }}
        >
          <label className="min-w-48 flex-1 text-sm">
            Cart
            <select
              value={cartId}
              onChange={(e) => setCartId(e.target.value)}
              className="mt-1 block min-h-11 w-full rounded-lg border border-line bg-bg px-3"
            >
              {data.carts.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </label>
          <label className="text-sm">
            Cycle
            <select
              value={auditType}
              onChange={(e) => setAuditType(e.target.value)}
              className="mt-1 block min-h-11 rounded-lg border border-line bg-bg px-3"
            >
              <option value="monthly">Monthly</option>
              <option value="quarterly">Quarterly</option>
            </select>
          </label>
          <button type="submit" className="min-h-11 rounded-full bg-primary px-5 text-primary-ink">
            Start audit
          </button>
        </form>
      ) : (
        <p className="text-sm text-muted">Managers can review audits. Pharmacy, quality, or an admin starts them.</p>
      )}
      <ul className="divide-y divide-line overflow-hidden rounded-card border border-line bg-surface">
        {data.audits.length === 0 ? (
          <li className="px-4 py-6 text-sm text-muted">No audits recorded for this hospital yet.</li>
        ) : null}
        {data.audits.map((a) => (
          <li key={a.id}>
            <button
              type="button"
              className="flex w-full items-center justify-between gap-3 px-4 py-3 text-left"
              onClick={() => navigate({ to: "/audits/$auditId", params: { auditId: a.id } })}
            >
              <span>
                <span className="block font-medium">{a.cart_name}</span>
                <span className="text-sm capitalize text-muted">
                  {a.audit_type} · {a.status}
                  {a.gaps ? ` · ${a.gaps} gaps` : " · complete"}
                </span>
              </span>
              <span className="text-sm text-primary">Open</span>
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}
