export type StarterItem = {
  name: string;
  kind: "medicine" | "surgical" | "misc";
  category: string;
  strength: string;
};

/** Standard crash-cart contents. Hospitals can add more after creation. */
export const STARTER_ITEMS: StarterItem[] = [
  { name: "Epinephrine", kind: "medicine", category: "ACLS", strength: "1 mg/mL" },
  { name: "Amiodarone", kind: "medicine", category: "ACLS", strength: "150 mg" },
  { name: "Atropine", kind: "medicine", category: "ACLS", strength: "1 mg" },
  { name: "Adenosine", kind: "medicine", category: "ACLS", strength: "6 mg" },
  { name: "Lidocaine", kind: "medicine", category: "ACLS", strength: "100 mg" },
  { name: "Sodium bicarbonate", kind: "medicine", category: "ACLS", strength: "8.4%" },
  { name: "Calcium chloride", kind: "medicine", category: "ACLS", strength: "10%" },
  { name: "Magnesium sulfate", kind: "medicine", category: "ACLS", strength: "2 g" },
  { name: "Norepinephrine", kind: "medicine", category: "Vasopressor", strength: "4 mg" },
  { name: "Dextrose", kind: "medicine", category: "Metabolic", strength: "50%" },
  { name: "Normal saline", kind: "medicine", category: "Fluid", strength: "500 mL" },
  { name: "Naloxone", kind: "medicine", category: "Reversal", strength: "0.4 mg" },
  { name: "Endotracheal tubes (assorted)", kind: "surgical", category: "Airway", strength: "" },
  { name: "Laryngoscope with blades", kind: "surgical", category: "Airway", strength: "" },
  { name: "Stylet", kind: "surgical", category: "Airway", strength: "" },
  { name: "Oropharyngeal airways", kind: "surgical", category: "Airway", strength: "" },
  { name: "Bag-valve-mask", kind: "surgical", category: "Airway", strength: "" },
  { name: "Suction catheters", kind: "surgical", category: "Airway", strength: "" },
  { name: "Oxygen mask with reservoir", kind: "surgical", category: "Airway", strength: "" },
  { name: "IV cannulas (assorted)", kind: "surgical", category: "Access", strength: "" },
  { name: "IV administration sets", kind: "surgical", category: "Access", strength: "" },
  { name: "Syringes (assorted)", kind: "surgical", category: "Access", strength: "" },
  { name: "Needles", kind: "surgical", category: "Access", strength: "" },
  { name: "Defibrillator pads", kind: "surgical", category: "Defib", strength: "" },
  { name: "ECG electrodes", kind: "surgical", category: "Defib", strength: "" },
  { name: "Tourniquet", kind: "surgical", category: "Access", strength: "" },
  { name: "Alcohol swabs", kind: "surgical", category: "Access", strength: "" },
  { name: "Sterile gloves", kind: "misc", category: "PPE", strength: "" },
  { name: "Non-sterile gloves", kind: "misc", category: "PPE", strength: "" },
  { name: "Adhesive tape", kind: "misc", category: "Dressing", strength: "" },
  { name: "Gauze pads", kind: "misc", category: "Dressing", strength: "" },
  { name: "Trauma scissors", kind: "misc", category: "Tools", strength: "" },
  { name: "Three-way stopcock", kind: "misc", category: "Access", strength: "" },
];

export const DRAWER_NAMES = ["Floor 1", "Floor 2", "Floor 3", "Floor 4"] as const;

export const ROLES = ["hospital_admin", "pharmacy", "quality", "manager"] as const;
export type Role = (typeof ROLES)[number];

export function roleLabel(role: string) {
  switch (role) {
    case "super_admin":
      return "Super admin";
    case "hospital_admin":
      return "Hospital admin";
    case "pharmacy":
      return "Pharmacy";
    case "quality":
      return "Quality";
    case "manager":
      return "Manager";
    default:
      return role;
  }
}
