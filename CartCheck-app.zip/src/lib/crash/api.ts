import { createServerFn } from "@tanstack/react-start";
import { authMiddleware } from "@/lib/auth/middleware";
import { getSql } from "@/lib/db";
import { DRAWER_NAMES, ROLES, STARTER_ITEMS, type Role } from "@/lib/crash/catalog";

function id() {
  return crypto.randomUUID();
}

type Sql = Awaited<ReturnType<typeof getSql>>;

const SUPER_EMAIL = "superadmin@cartcheck.local";

async function callerEmail(sql: Sql, userId: string) {
  const users = await sql<{ email: string }>`select email from "user" where id = ${userId}`;
  return (users[0]?.email ?? "").toLowerCase();
}

export const ensureSuperAdmin = createServerFn({ method: "POST" }).handler(async () => {
  const sql = await getSql();
  const existing = await sql<{ id: string }>`
    select id from "user" where lower(email) = ${SUPER_EMAIL}
  `;
  if (existing[0]) return { ready: true };
  const { auth } = await import("@/lib/auth/server");
  await auth.api.signUpEmail({
    body: { email: SUPER_EMAIL, password: "SuperAdmin@123", name: "Super Admin" },
  });
  return { ready: true };
});

async function memberRole(sql: Sql, userId: string, hospitalId: string) {
  if ((await callerEmail(sql, userId)) === SUPER_EMAIL) return "hospital_admin";
  const rows = await sql<{ role: string }>`
    select role from memberships where user_id = ${userId} and hospital_id = ${hospitalId}
  `;
  return rows[0]?.role ?? null;
}

async function assertMember(sql: Sql, userId: string, hospitalId: string, roles?: Role[]) {
  const role = await memberRole(sql, userId, hospitalId);
  if (!role) throw new Error("You are not a member of this hospital.");
  if (roles && !roles.includes(role as Role)) throw new Error("Your role cannot do that.");
  return role;
}

async function assertSuper(sql: Sql, userId: string) {
  if ((await callerEmail(sql, userId)) !== SUPER_EMAIL) {
    throw new Error("Only Super Admin can add hospitals.");
  }
}

const MANAGE: Role[] = ["hospital_admin"];
const AUDIT: Role[] = ["hospital_admin", "pharmacy", "quality"];
const CLOSE: Role[] = ["hospital_admin", "quality", "manager"];

export const getWorkspace = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    const users = await sql<{ id: string; email: string; name: string }>`
      select id, email, name from "user" where id = ${context.userId}
    `;
    const me = users[0];
    const isSuper = (me?.email ?? "").toLowerCase() === SUPER_EMAIL;
    if (me?.email && !isSuper) {
      const pending = await sql<{ id: string; hospital_id: string; role: string }>`
        select id, hospital_id, role from invites where lower(email) = lower(${me.email})
      `;
      for (const inv of pending) {
        await sql`
          insert into memberships (user_id, hospital_id, role)
          values (${context.userId}, ${inv.hospital_id}, ${inv.role})
          on conflict (user_id, hospital_id) do nothing
        `;
        await sql`delete from invites where id = ${inv.id}`;
      }
    }
    const hospitals = isSuper
      ? await sql<{ id: string; name: string; code: string; role: string }>`
          select id, name, code, ${"super_admin"} as role from hospitals order by name
        `
      : await sql<{ id: string; name: string; code: string; role: string }>`
          select h.id, h.name, h.code, m.role
          from memberships m
          join hospitals h on h.id = m.hospital_id
          where m.user_id = ${context.userId}
          order by h.name
        `;
    return {
      user: { id: context.userId, email: me?.email ?? "", name: me?.name ?? "" },
      isSuper,
      hospitals,
    };
  });

export const createHospital = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((data: { name: string; code: string }) => {
    const name = data.name.trim();
    const code = data.code.trim().toUpperCase();
    if (name.length < 2 || code.length < 2) throw new Error("Name and short code are required.");
    return { name, code };
  })
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await assertSuper(sql, context.userId);
    const hospitalId = id();
    await sql`
      insert into hospitals (id, name, code, created_by)
      values (${hospitalId}, ${data.name}, ${data.code}, ${context.userId})
    `;
    await sql`
      insert into memberships (user_id, hospital_id, role)
      values (${context.userId}, ${hospitalId}, ${"hospital_admin"})
    `;

    for (const item of STARTER_ITEMS) {
      await sql`
        insert into items (id, hospital_id, name, kind, category, strength)
        values (${id()}, ${hospitalId}, ${item.name}, ${item.kind}, ${item.category}, ${item.strength})
      `;
    }

    const seeds = [
      { name: "ICU Crash Cart", location: "ICU", cart_type: "ICU" },
      { name: "Emergency Crash Cart", location: "Emergency", cart_type: "Emergency" },
      { name: "Ward Crash Cart", location: "Medical ward", cart_type: "Ward" },
    ];
    for (const seed of seeds) {
      const cartId = id();
      await sql`
        insert into carts (id, hospital_id, name, location, cart_type)
        values (${cartId}, ${hospitalId}, ${seed.name}, ${seed.location}, ${seed.cart_type})
      `;
      for (let i = 0; i < DRAWER_NAMES.length; i++) {
        await sql`
          insert into drawers (id, cart_id, sort_order, name)
          values (${id()}, ${cartId}, ${i}, ${DRAWER_NAMES[i]})
        `;
      }
    }
    return { id: hospitalId };
  });

export const getDashboard = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .validator((data: { hospitalId: string }) => data)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const role = await assertMember(sql, context.userId, data.hospitalId);
    const isSuper = (await callerEmail(sql, context.userId)) === SUPER_EMAIL;
    const carts = await sql<{ id: string; name: string; location: string; cart_type: string }>`
      select id, name, location, cart_type from carts
      where hospital_id = ${data.hospitalId}
      order by name
    `;
    const open = await sql<{ n: number }>`
      select count(*)::int as n from audits
      where hospital_id = ${data.hospitalId} and status <> 'closed'
    `;
    const recent = await sql<{
      id: string;
      cart_name: string;
      audit_type: string;
      status: string;
      created_at: string;
    }>`
      select a.id, c.name as cart_name, a.audit_type, a.status, a.created_at::text as created_at
      from audits a
      join carts c on c.id = a.cart_id
      where a.hospital_id = ${data.hospitalId}
      order by a.created_at desc
      limit 8
    `;
    const gaps = await sql<{ n: number }>`
      select count(*)::int as n
      from audit_lines l
      join audits a on a.id = l.audit_id
      where a.hospital_id = ${data.hospitalId}
        and a.status <> 'closed'
        and l.line_status <> 'present'
    `;
    return {
      role: isSuper ? "super_admin" : role,
      isSuper,
      cartCount: carts.length,
      openAudits: open[0]?.n ?? 0,
      openGaps: gaps[0]?.n ?? 0,
      carts,
      recent,
    };
  });

export const listItems = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .validator((data: { hospitalId: string }) => data)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const role = await assertMember(sql, context.userId, data.hospitalId);
    const isSuper = (await callerEmail(sql, context.userId)) === SUPER_EMAIL;
    const items = await sql<{
      id: string;
      name: string;
      kind: string;
      category: string;
      strength: string;
      is_active: boolean;
    }>`
      select id, name, kind, category, strength, is_active
      from items where hospital_id = ${data.hospitalId}
      order by kind, category, name
    `;
    return { role: isSuper ? "super_admin" : role, items };
  });

export const addItem = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((data: { hospitalId: string; name: string; kind: string; category: string; strength: string }) => {
    if (!data.name.trim()) throw new Error("Name is required.");
    if (!["medicine", "surgical", "misc"].includes(data.kind)) throw new Error("Pick medicine, surgical, or misc.");
    return {
      ...data,
      name: data.name.trim(),
      category: data.category.trim() || "General",
      strength: data.strength.trim(),
    };
  })
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await assertMember(sql, context.userId, data.hospitalId, MANAGE);
    const itemId = id();
    await sql`
      insert into items (id, hospital_id, name, kind, category, strength)
      values (${itemId}, ${data.hospitalId}, ${data.name}, ${data.kind}, ${data.category}, ${data.strength})
    `;
    return { id: itemId };
  });

export const listCarts = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .validator((data: { hospitalId: string }) => data)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const role = await assertMember(sql, context.userId, data.hospitalId);
    const isSuper = (await callerEmail(sql, context.userId)) === SUPER_EMAIL;
    const carts = await sql<{
      id: string;
      name: string;
      location: string;
      cart_type: string;
      drawers: number;
      lines: number;
    }>`
      select c.id, c.name, c.location, c.cart_type,
        (select count(*)::int from drawers d where d.cart_id = c.id) as drawers,
        (select count(*)::int from cart_items ci join drawers d on d.id = ci.drawer_id where d.cart_id = c.id) as lines
      from carts c
      where c.hospital_id = ${data.hospitalId}
      order by c.name
    `;
    return { role: isSuper ? "super_admin" : role, carts };
  });

export const createCart = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((data: { hospitalId: string; name: string; location: string; cartType: string }) => {
    if (!data.name.trim() || !data.location.trim()) throw new Error("Name and location are required.");
    return { ...data, name: data.name.trim(), location: data.location.trim() };
  })
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await assertMember(sql, context.userId, data.hospitalId, MANAGE);
    const cartId = id();
    await sql`
      insert into carts (id, hospital_id, name, location, cart_type)
      values (${cartId}, ${data.hospitalId}, ${data.name}, ${data.location}, ${data.cartType || "Ward"})
    `;
    for (let i = 0; i < DRAWER_NAMES.length; i++) {
      await sql`
        insert into drawers (id, cart_id, sort_order, name)
        values (${id()}, ${cartId}, ${i}, ${DRAWER_NAMES[i]})
      `;
    }
    return { id: cartId };
  });

export const getCart = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .validator((data: { hospitalId: string; cartId: string }) => data)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const role = await assertMember(sql, context.userId, data.hospitalId);
    const isSuper = (await callerEmail(sql, context.userId)) === SUPER_EMAIL;
    const carts = await sql<{ id: string; name: string; location: string; cart_type: string }>`
      select id, name, location, cart_type from carts
      where id = ${data.cartId} and hospital_id = ${data.hospitalId}
    `;
    const cart = carts[0];
    if (!cart) throw new Error("Cart not found.");
    const drawers = await sql<{ id: string; name: string; sort_order: number }>`
      select id, name, sort_order from drawers where cart_id = ${data.cartId} order by sort_order
    `;
    const lines = await sql<{
      id: string;
      drawer_id: string;
      item_id: string;
      name: string;
      kind: string;
      strength: string;
      fixed_qty: number;
    }>`
      select ci.id, ci.drawer_id, ci.item_id, i.name, i.kind, i.strength, ci.fixed_qty
      from cart_items ci
      join items i on i.id = ci.item_id
      join drawers d on d.id = ci.drawer_id
      where d.cart_id = ${data.cartId}
      order by i.name
    `;
    const catalog = await sql<{ id: string; name: string; kind: string; strength: string }>`
      select id, name, kind, strength from items
      where hospital_id = ${data.hospitalId} and is_active = true
      order by name
    `;
    return { role: isSuper ? "super_admin" : role, cart, drawers, lines, catalog };
  });

export const assignItem = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((data: { hospitalId: string; drawerId: string; itemId: string; qty: number }) => data)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await assertMember(sql, context.userId, data.hospitalId, MANAGE);
    const ok = await sql<{ id: string }>`
      select d.id from drawers d
      join carts c on c.id = d.cart_id
      where d.id = ${data.drawerId} and c.hospital_id = ${data.hospitalId}
    `;
    if (!ok[0]) throw new Error("Floor not found.");
    await sql`
      insert into cart_items (id, drawer_id, item_id, fixed_qty)
      values (${id()}, ${data.drawerId}, ${data.itemId}, ${Math.max(1, data.qty || 1)})
    `;
    return { ok: true };
  });

export const addFloorItem = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator(
    (data: { hospitalId: string; drawerId: string; name: string; kind: string; strength: string; qty: number }) => {
      if (!data.name.trim()) throw new Error("Name is required.");
      if (!["medicine", "surgical", "misc"].includes(data.kind)) throw new Error("Pick a type.");
      return { ...data, name: data.name.trim(), strength: data.strength.trim() };
    },
  )
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await assertMember(sql, context.userId, data.hospitalId, MANAGE);
    const ok = await sql<{ id: string }>`
      select d.id from drawers d
      join carts c on c.id = d.cart_id
      where d.id = ${data.drawerId} and c.hospital_id = ${data.hospitalId}
    `;
    if (!ok[0]) throw new Error("Floor not found.");
    const itemId = id();
    await sql`
      insert into items (id, hospital_id, name, kind, category, strength)
      values (${itemId}, ${data.hospitalId}, ${data.name}, ${data.kind}, ${data.kind}, ${data.strength})
    `;
    await sql`
      insert into cart_items (id, drawer_id, item_id, fixed_qty)
      values (${id()}, ${data.drawerId}, ${itemId}, ${Math.max(1, Number(data.qty) || 1)})
    `;
    return { id: itemId };
  });

export const listAudits = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .validator((data: { hospitalId: string }) => data)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const role = await assertMember(sql, context.userId, data.hospitalId);
    const isSuper = (await callerEmail(sql, context.userId)) === SUPER_EMAIL;
    const audits = await sql<{
      id: string;
      cart_id: string;
      cart_name: string;
      audit_type: string;
      status: string;
      created_at: string;
      gaps: number;
    }>`
      select a.id, a.cart_id, c.name as cart_name, a.audit_type, a.status,
        a.created_at::text as created_at,
        (select count(*)::int from audit_lines l where l.audit_id = a.id and l.line_status <> 'present') as gaps
      from audits a
      join carts c on c.id = a.cart_id
      where a.hospital_id = ${data.hospitalId}
      order by a.created_at desc
    `;
    const carts = await sql<{ id: string; name: string }>`
      select id, name from carts where hospital_id = ${data.hospitalId} order by name
    `;
    return { role: isSuper ? "super_admin" : role, audits, carts };
  });

export const startAudit = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((data: { hospitalId: string; cartId: string; auditType: string }) => {
    if (data.auditType !== "monthly" && data.auditType !== "quarterly") {
      throw new Error("Choose monthly or quarterly.");
    }
    return data;
  })
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await assertMember(sql, context.userId, data.hospitalId, AUDIT);
    const cart = await sql<{ id: string }>`
      select id from carts where id = ${data.cartId} and hospital_id = ${data.hospitalId}
    `;
    if (!cart[0]) throw new Error("Cart not found.");
    const auditId = id();
    await sql`
      insert into audits (id, hospital_id, cart_id, audit_type, auditor_id, status)
      values (${auditId}, ${data.hospitalId}, ${data.cartId}, ${data.auditType}, ${context.userId}, ${"draft"})
    `;
    const lines = await sql<{ id: string; item_name: string; drawer_name: string; fixed_qty: number }>`
      select ci.id, i.name as item_name, d.name as drawer_name, ci.fixed_qty
      from cart_items ci
      join items i on i.id = ci.item_id
      join drawers d on d.id = ci.drawer_id
      where d.cart_id = ${data.cartId}
      order by d.sort_order, i.name
    `;
    for (const line of lines) {
      await sql`
        insert into audit_lines (id, audit_id, cart_item_id, item_name, drawer_name, fixed_qty, line_status)
        values (${id()}, ${auditId}, ${line.id}, ${line.item_name}, ${line.drawer_name}, ${line.fixed_qty}, ${"present"})
      `;
    }
    return { id: auditId };
  });

export const getAudit = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .validator((data: { hospitalId: string; auditId: string }) => data)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const role = await assertMember(sql, context.userId, data.hospitalId);
    const isSuper = (await callerEmail(sql, context.userId)) === SUPER_EMAIL;
    const rows = await sql<{
      id: string;
      cart_name: string;
      location: string;
      audit_type: string;
      status: string;
      remarks: string;
      created_at: string;
    }>`
      select a.id, c.name as cart_name, c.location, a.audit_type, a.status, a.remarks,
        a.created_at::text as created_at
      from audits a
      join carts c on c.id = a.cart_id
      where a.id = ${data.auditId} and a.hospital_id = ${data.hospitalId}
    `;
    const audit = rows[0];
    if (!audit) throw new Error("Audit not found.");
    const lines = await sql<{
      id: string;
      item_name: string;
      drawer_name: string;
      fixed_qty: number;
      line_status: string;
      label_note: string;
      remarks: string;
    }>`
      select id, item_name, drawer_name, fixed_qty, line_status, label_note, remarks
      from audit_lines where audit_id = ${data.auditId}
      order by drawer_name, item_name
    `;
    return { role: isSuper ? "super_admin" : role, audit, lines };
  });

export const saveLine = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator(
    (data: { hospitalId: string; lineId: string; lineStatus: string; labelNote: string; remarks: string }) => data,
  )
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await assertMember(sql, context.userId, data.hospitalId, AUDIT);
    const allowed = ["present", "absent", "expired", "damaged", "near_expiry"];
    if (!allowed.includes(data.lineStatus)) throw new Error("Invalid status.");
    await sql`
      update audit_lines l set
        line_status = ${data.lineStatus},
        label_note = ${data.labelNote},
        remarks = ${data.remarks}
      from audits a
      where l.id = ${data.lineId}
        and l.audit_id = a.id
        and a.hospital_id = ${data.hospitalId}
        and a.status = 'draft'
    `;
    return { ok: true };
  });

export const setAuditStatus = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((data: { hospitalId: string; auditId: string; status: string; remarks: string }) => data)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const role = await assertMember(sql, context.userId, data.hospitalId);
    if (data.status === "submitted") {
      if (!AUDIT.includes(role as Role)) throw new Error("Your role cannot submit audits.");
    } else if (data.status === "closed" || data.status === "draft") {
      if (!CLOSE.includes(role as Role) && !(data.status === "draft" && AUDIT.includes(role as Role))) {
        throw new Error("Your role cannot change this audit.");
      }
    } else {
      throw new Error("Invalid status.");
    }
    await sql`
      update audits set status = ${data.status}, remarks = ${data.remarks}
      where id = ${data.auditId} and hospital_id = ${data.hospitalId}
    `;
    return { ok: true };
  });

export const inviteMember = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((data: { hospitalId: string; email: string; role: string }) => {
    const email = data.email.trim().toLowerCase();
    if (!email.includes("@")) throw new Error("Enter a valid email.");
    if (!ROLES.includes(data.role as Role)) throw new Error("Pick a role.");
    return { ...data, email, role: data.role as Role };
  })
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await assertMember(sql, context.userId, data.hospitalId, MANAGE);
    const existing = await sql<{ id: string }>`
      select id from "user" where lower(email) = ${data.email}
    `;
    if (existing[0]) {
      await sql`
        insert into memberships (user_id, hospital_id, role)
        values (${existing[0].id}, ${data.hospitalId}, ${data.role})
        on conflict (user_id, hospital_id) do update set role = ${data.role}
      `;
      return { joined: true };
    }
    await sql`
      insert into invites (id, hospital_id, email, role)
      values (${id()}, ${data.hospitalId}, ${data.email}, ${data.role})
      on conflict (hospital_id, email) do update set role = ${data.role}
    `;
    return { joined: false };
  });

export const listMembers = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .validator((data: { hospitalId: string }) => data)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await assertMember(sql, context.userId, data.hospitalId);
    const members = await sql<{ email: string; name: string; role: string }>`
      select u.email, u.name, m.role
      from memberships m
      join "user" u on u.id = m.user_id
      where m.hospital_id = ${data.hospitalId}
      order by u.email
    `;
    const pending = await sql<{ email: string; role: string }>`
      select email, role from invites where hospital_id = ${data.hospitalId} order by email
    `;
    return { members, pending };
  });
