create table if not exists hospitals (
  id text primary key,
  name text not null,
  code text not null,
  created_by text not null,
  created_at timestamptz not null default now()
);

create table if not exists memberships (
  user_id text not null,
  hospital_id text not null references hospitals(id) on delete cascade,
  role text not null,
  created_at timestamptz not null default now(),
  primary key (user_id, hospital_id)
);

create table if not exists invites (
  id text primary key,
  hospital_id text not null references hospitals(id) on delete cascade,
  email text not null,
  role text not null,
  created_at timestamptz not null default now(),
  unique (hospital_id, email)
);

create table if not exists items (
  id text primary key,
  hospital_id text not null references hospitals(id) on delete cascade,
  name text not null,
  kind text not null,
  category text not null,
  strength text not null default '',
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists carts (
  id text primary key,
  hospital_id text not null references hospitals(id) on delete cascade,
  name text not null,
  location text not null,
  cart_type text not null,
  created_at timestamptz not null default now()
);

create table if not exists drawers (
  id text primary key,
  cart_id text not null references carts(id) on delete cascade,
  sort_order int not null,
  name text not null
);

create table if not exists cart_items (
  id text primary key,
  drawer_id text not null references drawers(id) on delete cascade,
  item_id text not null references items(id) on delete cascade,
  fixed_qty int not null default 1
);

create table if not exists audits (
  id text primary key,
  hospital_id text not null references hospitals(id) on delete cascade,
  cart_id text not null references carts(id) on delete cascade,
  audit_type text not null,
  auditor_id text not null,
  status text not null,
  remarks text not null default '',
  created_at timestamptz not null default now()
);

create table if not exists audit_lines (
  id text primary key,
  audit_id text not null references audits(id) on delete cascade,
  cart_item_id text not null,
  item_name text not null,
  drawer_name text not null,
  fixed_qty int not null,
  line_status text not null,
  label_note text not null default '',
  remarks text not null default ''
);

create index if not exists memberships_user_idx on memberships (user_id);
create index if not exists items_hospital_idx on items (hospital_id);
create index if not exists carts_hospital_idx on carts (hospital_id);
create index if not exists audits_hospital_idx on audits (hospital_id);
