update drawers
set name = 'Floor ' || (sort_order + 1)::text
where name in ('Medications', 'Airway', 'Circulation', 'Miscellaneous');
